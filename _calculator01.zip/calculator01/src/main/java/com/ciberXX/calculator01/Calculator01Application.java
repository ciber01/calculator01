package com.ciberXX.calculator01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Calculator01Application {

	public static void main(String[] args) {
		SpringApplication.run(Calculator01Application.class, args);
	}

}
