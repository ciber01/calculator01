package com.ciberXX.calculator01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Calculator01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
